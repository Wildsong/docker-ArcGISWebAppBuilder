* Public methods:
  * addRepublishEvent
  * previewOnDevice

* For "popup-app-actions" extension point, all extensions should have these properties:
	`disabled`: default: false
	`visible`: default: true
	`label`:

* For "app-actions" extension point, all extensions should have these properties:
	`visible`: default true

* All extensions for the following extension point should have `visible` property and `refresh` method:
	config-template:
	template-config-part:
